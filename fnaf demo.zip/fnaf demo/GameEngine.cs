﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fnaf_demo
{
    internal class GameEngine
    {
        public Ufficio ufficio = new Ufficio(false, false, false, false, 100, 0.1f);
    }
}

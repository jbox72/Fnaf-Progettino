﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace fnaf_demo
{
    internal class GameEngine
    {
        public DispatcherTimer T;
        public Ufficio ufficio;
        public int contatoreTick = 0;
        public Fenicottero fenicottero_anim;
        public Rana rana_anim;
        public Procione procione_anim;
        public Camere camere;
        public event EventHandler Tick;

        public Image imgjumpscare;
        public Image jumpscareShake;

        public GameEngine()
        {
            ufficio = new Ufficio(false, false, false, false, 100, 0.1f);
            camere = new Camere();
            this.fenicottero_anim = new Fenicottero();
            this.procione_anim = new Procione();
            this.rana_anim = new Rana();
            T = new DispatcherTimer();
            T.Interval = TimeSpan.FromMilliseconds(300);

            T.Tick += GestisciTick;
            T.Start();
        }

        private void GestisciTick(object sender, EventArgs e)
        {
            contatoreTick++;

            if (procione_anim.stanzaAttuale == 11)
            {
                T.Stop();

                DispatcherTimer timer = new DispatcherTimer();
                timer.Interval = TimeSpan.FromMilliseconds(30);
                int frameIndex = 0;
                Random shakeRnd = new Random();

                imgjumpscare.Visibility = Visibility.Visible;
                imgjumpscare.Source = new BitmapImage(new Uri("immagini/jumpscare_procione.jpg", UriKind.Relative));

                TranslateTransform tremore = new TranslateTransform(0, 0);
                imgjumpscare.RenderTransform = tremore;

                timer.Tick += (s, ev) => {

                    double intensita = 50; 
                    tremore.X = (shakeRnd.NextDouble() * 2 - 1) * intensita;
                    tremore.Y = (shakeRnd.NextDouble() * 2 - 1) * intensita;

                    frameIndex++;
                    if (frameIndex >= 50)
                    {
                        timer.Stop();
                        tremore.X = 0;
                        tremore.Y = 0;

                    }
                };
                timer.Start();
            }
            if (rana_anim.stanzaAttuale == 11)
            {
                //jumpscare, game over,procione
                T.Stop();
            }
            if (Ogni(1))
            {
                camere.statoinizio = false;
            }
            if (Ogni(10))
            {
               fenicottero_anim.Avanza();
            }
            if (Ogni(2))
            {
                rana_anim.Avanza();
            }
            if (Ogni(1))
            {
                 procione_anim.Avanza();
            }
            if (Ogni(3))
            {
                ufficio.ConsumaBatteria();
            }
            if (Ogni(2))
            {
                ufficio.EvolviOrario();
            }

            if (Tick != null)
            {
                Tick(this, EventArgs.Empty);
            }
        }

        public bool Ogni(int numeroTick)
        {
            if (contatoreTick == 0)
            {
                return false;
            }

            if (contatoreTick % numeroTick == 0)
            {
                return true;
            }

            return false;
        }
    }
}
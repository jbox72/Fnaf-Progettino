﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace fnaf_demo
{
    public partial class MainWindow : Window
    {
        GameEngine gameEngine = new GameEngine();

        public MainWindow()
        {
            InitializeComponent();

            gameEngine.Tick += Tick_gioco;
        }

        private void Tick_gioco(object sender, EventArgs e)
        {
            float b = gameEngine.ufficio.getBatteria();
            int i = (int)b;

            Batteria_text.Text = i.ToString() + "%";
        } 
    }
}